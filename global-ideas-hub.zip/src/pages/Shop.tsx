import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ShoppingCart, Search, Filter, ArrowRight, Star, Download, BookOpen, Video, FileText, Layout, Globe, Zap, Cpu, TrendingUp } from "lucide-react";
import { cn } from "../lib/utils";

const Shop = () => {
  const [activeCategory, setActiveCategory] = useState("All");

  const categories = ["All", "eBooks", "Courses", "Templates", "Strategic Reports", "Toolkits"];

  const products = [
    {
      id: 1,
      title: "The Strategic Innovation Blueprint",
      category: "eBooks",
      price: 49.99,
      rating: 4.9,
      reviews: 124,
      image: "https://picsum.photos/seed/book1/800/600",
      icon: BookOpen,
      tag: "Best Seller",
    },
    {
      id: 2,
      title: "Global Market Forecasting 2026",
      category: "Strategic Reports",
      price: 299.99,
      rating: 5.0,
      reviews: 45,
      image: "https://picsum.photos/seed/report1/800/600",
      icon: TrendingUp,
      tag: "Premium",
    },
    {
      id: 3,
      title: "Innovation Leadership Masterclass",
      category: "Courses",
      price: 149.99,
      rating: 4.8,
      reviews: 89,
      image: "https://picsum.photos/seed/course1/800/600",
      icon: Video,
      tag: "Popular",
    },
    {
      id: 4,
      title: "Strategic Roadmap Templates",
      category: "Templates",
      price: 29.99,
      rating: 4.7,
      reviews: 210,
      image: "https://picsum.photos/seed/template1/800/600",
      icon: Layout,
      tag: "New",
    },
    {
      id: 5,
      title: "Global Impact Toolkit",
      category: "Toolkits",
      price: 79.99,
      rating: 4.9,
      reviews: 67,
      image: "https://picsum.photos/seed/toolkit1/800/600",
      icon: Zap,
      tag: "Featured",
    },
    {
      id: 6,
      title: "Intelligence Module Framework",
      category: "Strategic Reports",
      price: 199.99,
      rating: 5.0,
      reviews: 32,
      image: "https://picsum.photos/seed/framework1/800/600",
      icon: Cpu,
      tag: "Exclusive",
    },
  ];

  const filteredProducts = activeCategory === "All" ? products : products.filter(p => p.category === activeCategory);

  return (
    <div className="bg-black text-white pt-24 min-h-screen">
      {/* Hero Section */}
      <section className="py-24 px-6 relative overflow-hidden">
        <div className="max-w-7xl mx-auto text-center space-y-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <span className="inline-block px-4 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-500 text-xs font-bold uppercase tracking-[0.2em]">
              Digital Resources
            </span>
            <h1 className="text-6xl md:text-8xl font-black tracking-tighter leading-[0.9]">
              INTELLECTUAL <span className="text-orange-500 italic">CAPITAL.</span>
            </h1>
            <p className="text-lg text-white/60 max-w-2xl mx-auto">
              Access the world's most comprehensive library of strategic resources, toolkits, and intelligence reports.
            </p>
          </motion.div>
        </div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-orange-500/5 blur-[120px] rounded-full -z-10" />
      </section>

      {/* Filter & Search Section */}
      <section className="py-12 px-6 sticky top-[80px] z-40 bg-black/80 backdrop-blur-md border-y border-white/5">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="flex items-center gap-4 overflow-x-auto no-scrollbar w-full lg:w-auto pb-2 lg:pb-0">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={cn(
                  "px-8 py-3 rounded-full text-sm font-bold whitespace-nowrap transition-all",
                  activeCategory === cat
                    ? "bg-orange-500 text-white"
                    : "bg-white/5 text-white/60 hover:bg-white/10"
                )}
              >
                {cat}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-4 w-full lg:w-auto">
            <div className="relative flex-1 lg:w-80">
              <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-white/40 w-5 h-5" />
              <input
                type="text"
                placeholder="Search resources..."
                className="w-full bg-white/5 border border-white/10 rounded-full px-14 py-4 focus:outline-none focus:border-orange-500 transition-colors"
              />
            </div>
            <button className="w-14 h-14 bg-white/5 border border-white/10 rounded-full flex items-center justify-center hover:bg-orange-500 transition-colors group">
              <Filter className="w-5 h-5 group-hover:scale-110 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <AnimatePresence mode="popLayout">
              {filteredProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.4, delay: index * 0.05 }}
                  className="group bg-white/5 border border-white/10 rounded-[2.5rem] overflow-hidden hover:border-orange-500 transition-all flex flex-col"
                >
                  <div className="relative h-72 overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60" />
                    <div className="absolute top-6 left-6">
                      <div className="bg-orange-500 text-white p-3 rounded-2xl">
                        <product.icon className="w-6 h-6" />
                      </div>
                    </div>
                    <div className="absolute top-6 right-6">
                      <span className="text-[10px] font-bold uppercase tracking-widest bg-orange-500 text-white px-3 py-1 rounded-full">
                        {product.tag}
                      </span>
                    </div>
                    <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-widest bg-white/10 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
                        {product.category}
                      </span>
                      <div className="flex items-center gap-1 text-orange-500">
                        <Star className="w-3 h-3 fill-current" />
                        <span className="text-[10px] font-bold">{product.rating}</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-10 space-y-6 flex-1 flex flex-col">
                    <div className="space-y-2">
                      <h3 className="text-2xl font-bold tracking-tight group-hover:text-orange-500 transition-colors">
                        {product.title}
                      </h3>
                      <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest">{product.reviews} Reviews</p>
                    </div>
                    <div className="flex items-center justify-between mt-auto pt-6 border-t border-white/10">
                      <span className="text-3xl font-black tracking-tighter">${product.price}</span>
                      <button className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-full font-bold text-sm flex items-center gap-2 transition-all transform hover:scale-105">
                        <ShoppingCart className="w-4 h-4" />
                        ADD TO CART
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-32 px-6">
        <div className="max-w-5xl mx-auto bg-orange-500 rounded-[4rem] p-12 md:p-24 text-center space-y-12 relative overflow-hidden">
          <div className="relative z-10 space-y-8">
            <h2 className="text-5xl md:text-8xl font-black tracking-tighter leading-[0.8] text-black">
              GET THE LATEST <span className="italic">INSIGHTS.</span>
            </h2>
            <p className="text-black/60 text-xl max-w-2xl mx-auto font-bold uppercase tracking-widest">
              Subscribe to our strategic newsletter and never miss an update.
            </p>
            <form className="max-w-md mx-auto relative">
              <input
                type="email"
                placeholder="Enter your email"
                className="w-full bg-black text-white border-none rounded-full px-10 py-6 focus:outline-none text-lg"
              />
              <button className="absolute right-2 top-2 bg-orange-500 text-black w-12 h-12 rounded-full flex items-center justify-center hover:bg-white transition-colors">
                <ArrowRight className="w-6 h-6" />
              </button>
            </form>
          </div>
          <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10" />
        </div>
      </section>
    </div>
  );
};

export default Shop;
