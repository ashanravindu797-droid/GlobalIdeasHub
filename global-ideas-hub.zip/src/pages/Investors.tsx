import React from "react";
import { motion } from "motion/react";
import { TrendingUp, Globe, Shield, Users, ArrowRight, CheckCircle2, BarChart3, PieChart, Landmark, Briefcase } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";

const Investors = () => {
  const data = [
    { name: "2020", value: 400 },
    { name: "2021", value: 700 },
    { name: "2022", value: 1200 },
    { name: "2023", value: 1800 },
    { name: "2024", value: 2400 },
    { name: "2025", value: 3200 },
  ];

  const features = [
    {
      title: "Institutional Access",
      description: "Direct access to pre-vetted, high-potential global innovation projects.",
      icon: Landmark,
    },
    {
      title: "Strategic Diversification",
      description: "Diversify your portfolio across multiple sectors and geographic regions.",
      icon: PieChart,
    },
    {
      title: "Due Diligence Support",
      description: "Comprehensive analysis and reporting for every investment opportunity.",
      icon: Shield,
    },
    {
      title: "Global Network",
      description: "Connect with other institutional and strategic investors worldwide.",
      icon: Globe,
    },
  ];

  return (
    <div className="bg-black text-white pt-24">
      {/* Hero Section */}
      <section className="py-24 px-6 relative overflow-hidden">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <span className="inline-block px-4 py-1.5 rounded-full bg-green-500/10 border border-green-500/30 text-green-500 text-xs font-bold uppercase tracking-[0.2em]">
              Investor Portal
            </span>
            <h1 className="text-6xl md:text-8xl font-black tracking-tighter leading-[0.9]">
              INSTITUTIONAL <span className="text-green-500 italic">CAPITAL</span> FOR GLOBAL IMPACT.
            </h1>
            <p className="text-lg text-white/60 max-w-xl leading-relaxed">
              Access the most exclusive pipeline of strategic innovation projects. We bridge the gap between visionary ideas and institutional capital.
            </p>
            <div className="flex flex-wrap gap-6 pt-4">
              <button className="bg-green-500 hover:bg-green-600 text-black px-10 py-5 rounded-full font-bold text-lg flex items-center gap-3 transition-all transform hover:scale-105">
                REQUEST ACCESS
                <ArrowRight className="w-5 h-5" />
              </button>
              <button className="bg-transparent border-2 border-white/20 text-white px-10 py-5 rounded-full font-bold text-lg hover:border-green-500 hover:text-green-500 transition-all transform hover:scale-105">
                VIEW PERFORMANCE
              </button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="bg-white/5 backdrop-blur-3xl p-8 rounded-[3rem] border border-white/10 relative z-10">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest text-white/40 mb-1">Portfolio Growth</p>
                  <h3 className="text-3xl font-black tracking-tighter text-green-500">+320% ROI</h3>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-2xl flex items-center justify-center">
                  <TrendingUp className="text-green-500 w-6 h-6" />
                </div>
              </div>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={data}>
                    <defs>
                      <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                    <XAxis dataKey="name" stroke="#ffffff40" fontSize={10} tickLine={false} axisLine={false} />
                    <YAxis hide />
                    <Tooltip
                      contentStyle={{ backgroundColor: "#000", border: "1px solid #ffffff20", borderRadius: "12px" }}
                      itemStyle={{ color: "#22c55e" }}
                    />
                    <Area type="monotone" dataKey="value" stroke="#22c55e" strokeWidth={4} fillOpacity={1} fill="url(#colorValue)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
            {/* Decorative Elements */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-green-500/20 blur-[80px] rounded-full -z-10" />
            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-blue-500/20 blur-[80px] rounded-full -z-10" />
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24 px-6 border-y border-white/5">
        <div className="max-w-7xl mx-auto grid grid-cols-2 lg:grid-cols-4 gap-12 text-center">
          <div>
            <h4 className="text-5xl font-black tracking-tighter mb-2">$1.2B+</h4>
            <p className="text-xs font-bold uppercase tracking-widest text-white/40">Capital Managed</p>
          </div>
          <div>
            <h4 className="text-5xl font-black tracking-tighter mb-2">3,100+</h4>
            <p className="text-xs font-bold uppercase tracking-widest text-white/40">Verified Investors</p>
          </div>
          <div>
            <h4 className="text-5xl font-black tracking-tighter mb-2">85+</h4>
            <p className="text-xs font-bold uppercase tracking-widest text-white/40">Countries Reached</p>
          </div>
          <div>
            <h4 className="text-5xl font-black tracking-tighter mb-2">24/7</h4>
            <p className="text-xs font-bold uppercase tracking-widest text-white/40">Strategic Support</p>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-32 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-20 space-y-6">
            <span className="text-green-500 font-bold uppercase tracking-[0.2em] text-xs">Institutional Access</span>
            <h2 className="text-5xl md:text-7xl font-black tracking-tighter leading-[0.9]">
              WHY INVEST WITH <span className="text-green-500">US?</span>
            </h2>
            <p className="text-white/60 text-lg">
              We provide the infrastructure and expertise needed for sophisticated global investment strategies.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="p-12 rounded-[3rem] bg-white/5 border border-white/10 hover:border-green-500 transition-all group flex gap-8 items-start"
              >
                <div className="w-16 h-16 bg-green-500/10 rounded-2xl flex items-center justify-center shrink-0 group-hover:bg-green-500 group-hover:rotate-12 transition-all">
                  <feature.icon className="w-8 h-8 text-green-500 group-hover:text-black transition-colors" />
                </div>
                <div className="space-y-4">
                  <h3 className="text-2xl font-bold">{feature.title}</h3>
                  <p className="text-white/60 leading-relaxed">{feature.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="py-32 px-6 bg-green-500">
        <div className="max-w-5xl mx-auto text-center space-y-12">
          <Landmark className="w-16 h-16 text-black mx-auto" />
          <h2 className="text-4xl md:text-6xl font-black tracking-tighter leading-[0.9] text-black">
            "THE GLOBAL IDEAS HUB HAS REVOLUTIONIZED HOW WE SOURCE STRATEGIC INNOVATION PROJECTS. THE QUALITY OF PIPELINE IS UNMATCHED."
          </h2>
          <div className="space-y-2">
            <p className="text-black font-black text-xl tracking-tighter uppercase">Marcus Thorne</p>
            <p className="text-black/60 font-bold text-sm uppercase tracking-widest">Managing Director, Thorne Capital</p>
          </div>
        </div>
      </section>

      {/* Access Form Section */}
      <section className="py-32 px-6">
        <div className="max-w-4xl mx-auto bg-white/5 p-12 md:p-20 rounded-[4rem] border border-white/10 relative overflow-hidden">
          <div className="relative z-10 space-y-12">
            <div className="text-center space-y-4">
              <h2 className="text-4xl md:text-6xl font-black tracking-tighter">REQUEST ACCESS</h2>
              <p className="text-white/60">Apply for institutional access to our strategic investment portal.</p>
            </div>
            <form className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-white/40 px-4">Full Name</label>
                <input type="text" className="w-full bg-black border border-white/10 rounded-full px-8 py-5 focus:outline-none focus:border-green-500 transition-colors" placeholder="John Doe" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-white/40 px-4">Organization</label>
                <input type="text" className="w-full bg-black border border-white/10 rounded-full px-8 py-5 focus:outline-none focus:border-green-500 transition-colors" placeholder="Organization Name" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-white/40 px-4">Professional Email</label>
                <input type="email" className="w-full bg-black border border-white/10 rounded-full px-8 py-5 focus:outline-none focus:border-green-500 transition-colors" placeholder="john@organization.com" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-white/40 px-4">Investment Scale</label>
                <select className="w-full bg-black border border-white/10 rounded-full px-8 py-5 focus:outline-none focus:border-green-500 transition-colors appearance-none">
                  <option>$1M - $10M</option>
                  <option>$10M - $50M</option>
                  <option>$50M+</option>
                </select>
              </div>
              <div className="md:col-span-2 pt-8">
                <button className="w-full bg-green-500 hover:bg-green-600 text-black py-6 rounded-full font-black text-xl tracking-tighter transition-all transform hover:scale-[1.02]">
                  SUBMIT APPLICATION
                </button>
              </div>
            </form>
          </div>
          <div className="absolute top-0 right-0 w-64 h-64 bg-green-500/5 blur-[100px] rounded-full -z-10" />
        </div>
      </section>
    </div>
  );
};

export default Investors;
