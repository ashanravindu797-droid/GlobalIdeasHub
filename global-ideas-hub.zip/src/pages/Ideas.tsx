import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Search, Filter, ArrowRight, Zap, Globe, TrendingUp, Cpu, Lightbulb, Users, Shield, Star, Clock } from "lucide-react";
import { cn } from "../lib/utils";

const Ideas = () => {
  const [activeFilter, setActiveFilter] = useState("All");

  const filters = ["All", "Technology", "Sustainability", "Finance", "Health", "Space"];

  const ideas = [
    {
      id: 1,
      title: "Quantum Neural Networks",
      category: "Technology",
      description: "A strategic framework for integrating quantum computing with neural network architectures for exponential processing power.",
      author: "Dr. Elena Vance",
      impact: "High",
      status: "Strategic Phase",
      image: "https://picsum.photos/seed/quantum/800/600",
      icon: Cpu,
    },
    {
      id: 2,
      title: "Regenerative Urban Ecosystems",
      category: "Sustainability",
      description: "A blueprint for self-sustaining urban environments that actively restore local biodiversity and manage resources autonomously.",
      author: "Julian Rivers",
      impact: "Global",
      status: "Concept Phase",
      image: "https://picsum.photos/seed/urban/800/600",
      icon: Globe,
    },
    {
      id: 3,
      title: "Decentralized Global Reserve",
      category: "Finance",
      description: "A new economic model for a decentralized global reserve currency backed by strategic innovation assets and real-world impact.",
      author: "Sarah Chen",
      impact: "High",
      status: "Development Phase",
      image: "https://picsum.photos/seed/finance/800/600",
      icon: TrendingUp,
    },
    {
      id: 4,
      title: "Personalized Genomic Medicine",
      category: "Health",
      description: "An AI-driven platform for real-time genomic analysis and personalized medical treatments based on individual DNA profiles.",
      author: "Dr. Marcus Thorne",
      impact: "High",
      status: "Clinical Phase",
      image: "https://picsum.photos/seed/health/800/600",
      icon: Shield,
    },
    {
      id: 5,
      title: "Autonomous Space Infrastructure",
      category: "Space",
      description: "Strategic planning for self-building and self-repairing infrastructure in low Earth orbit using advanced robotics and AI.",
      author: "Commander Leo Sky",
      impact: "Interstellar",
      status: "Strategic Phase",
      image: "https://picsum.photos/seed/space/800/600",
      icon: Zap,
    },
    {
      id: 6,
      title: "Bio-Digital Interfaces",
      category: "Technology",
      description: "Exploring the convergence of biological systems and digital interfaces for seamless human-machine collaboration.",
      author: "Aria Nova",
      impact: "High",
      status: "Research Phase",
      image: "https://picsum.photos/seed/bio/800/600",
      icon: Cpu,
    },
  ];

  const filteredIdeas = activeFilter === "All" ? ideas : ideas.filter(idea => idea.category === activeFilter);

  return (
    <div className="bg-black text-white pt-24 min-h-screen">
      {/* Header Section */}
      <section className="py-20 px-6 border-b border-white/5">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-end justify-between gap-12">
          <div className="max-w-2xl space-y-6">
            <span className="text-orange-500 font-bold uppercase tracking-[0.2em] text-xs">Innovation Repository</span>
            <h1 className="text-6xl md:text-8xl font-black tracking-tighter leading-[0.9]">
              BROWSE THE <span className="text-orange-500 italic">FUTURE.</span>
            </h1>
            <p className="text-white/60 text-lg max-w-xl">
              Explore a curated collection of strategic ideas and groundbreaking concepts from the world's leading innovators.
            </p>
          </div>
          <div className="flex items-center gap-4 w-full md:w-auto">
            <div className="relative flex-1 md:w-80">
              <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-white/40 w-5 h-5" />
              <input
                type="text"
                placeholder="Search ideas..."
                className="w-full bg-white/5 border border-white/10 rounded-full px-14 py-5 focus:outline-none focus:border-orange-500 transition-colors"
              />
            </div>
            <button className="w-16 h-16 bg-white/5 border border-white/10 rounded-full flex items-center justify-center hover:bg-orange-500 transition-colors group">
              <Filter className="w-6 h-6 group-hover:scale-110 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* Filter Section */}
      <section className="py-12 px-6 sticky top-[80px] z-40 bg-black/80 backdrop-blur-md border-b border-white/5">
        <div className="max-w-7xl mx-auto flex items-center gap-4 overflow-x-auto no-scrollbar pb-2">
          {filters.map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={cn(
                "px-8 py-3 rounded-full text-sm font-bold whitespace-nowrap transition-all",
                activeFilter === filter
                  ? "bg-orange-500 text-white"
                  : "bg-white/5 text-white/60 hover:bg-white/10"
              )}
            >
              {filter}
            </button>
          ))}
        </div>
      </section>

      {/* Ideas Grid */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <AnimatePresence mode="popLayout">
              {filteredIdeas.map((idea, index) => (
                <motion.div
                  key={idea.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.4, delay: index * 0.05 }}
                  className="group bg-white/5 border border-white/10 rounded-[2.5rem] overflow-hidden hover:border-orange-500 transition-all flex flex-col"
                >
                  <div className="relative h-64 overflow-hidden">
                    <img
                      src={idea.image}
                      alt={idea.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60" />
                    <div className="absolute top-6 left-6">
                      <div className="bg-orange-500 text-white p-3 rounded-2xl">
                        <idea.icon className="w-6 h-6" />
                      </div>
                    </div>
                    <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-widest bg-white/10 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
                        {idea.category}
                      </span>
                      <div className="flex items-center gap-1 text-orange-500">
                        <Star className="w-3 h-3 fill-current" />
                        <span className="text-[10px] font-bold">4.9</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-10 space-y-6 flex-1 flex flex-col">
                    <div className="space-y-2">
                      <h3 className="text-2xl font-bold tracking-tight group-hover:text-orange-500 transition-colors">
                        {idea.title}
                      </h3>
                      <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest">By {idea.author}</p>
                    </div>
                    <p className="text-white/60 text-sm leading-relaxed flex-1">
                      {idea.description}
                    </p>
                    <div className="pt-6 border-t border-white/10 flex items-center justify-between">
                      <div className="flex items-center gap-2 text-white/40">
                        <Clock className="w-4 h-4" />
                        <span className="text-[10px] font-bold uppercase tracking-widest">{idea.status}</span>
                      </div>
                      <button className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center hover:bg-orange-600 transition-colors group/btn">
                        <ArrowRight className="w-5 h-5 group-hover/btn:translate-x-1 transition-transform" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* Strategic Roadmap Section */}
      <section className="py-32 px-6 bg-white/5">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-20 space-y-6">
            <h2 className="text-5xl md:text-7xl font-black tracking-tighter leading-[0.9]">
              STRATEGIC <span className="text-orange-500">ROADMAP.</span>
            </h2>
            <p className="text-white/60 text-lg">
              Our structured approach to taking ideas from concept to global impact.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { step: "01", title: "Concept", desc: "Initial ideation and strategic alignment." },
              { step: "02", title: "Strategic Phase", desc: "Feasibility studies and market analysis." },
              { step: "03", title: "Development", desc: "Prototyping and initial implementation." },
              { step: "04", title: "Global Impact", desc: "Scaling and strategic deployment." },
            ].map((item, i) => (
              <div key={item.step} className="relative p-10 rounded-[2.5rem] bg-black border border-white/10 hover:border-orange-500 transition-all group">
                <span className="text-6xl font-black text-white/5 absolute top-6 right-6 group-hover:text-orange-500/10 transition-colors">{item.step}</span>
                <h3 className="text-2xl font-bold mb-4">{item.title}</h3>
                <p className="text-white/60 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Ideas;
