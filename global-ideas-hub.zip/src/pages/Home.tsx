import React from "react";
import { motion } from "motion/react";
import { ArrowRight, Play, Globe, Zap, Shield, TrendingUp, Users, Cpu, Briefcase, ShoppingBag } from "lucide-react";
import { Link } from "react-router-dom";

const Home = () => {
  const stats = [
    { label: "Active Innovators", value: "12,450+", icon: Users },
    { label: "Strategic Ideas", value: "8,920+", icon: Zap },
    { label: "Global Investors", value: "3,100+", icon: TrendingUp },
    { label: "Capital Deployed", value: "$1.2B+", icon: Briefcase },
  ];

  const modules = [
    {
      title: "Strategic Intelligence",
      description: "Advanced analytics and market forecasting for global trends.",
      icon: Cpu,
      color: "bg-blue-500",
    },
    {
      title: "Innovation Pipeline",
      description: "A structured journey from concept to market-ready solution.",
      icon: Zap,
      color: "bg-orange-500",
    },
    {
      title: "Investor Ecosystem",
      description: "Connecting high-potential ideas with strategic capital.",
      icon: TrendingUp,
      color: "bg-green-500",
    },
  ];

  return (
    <div className="bg-black text-white overflow-hidden">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <video
            autoPlay
            loop
            muted
            playsInline
            className="w-full h-full object-cover opacity-40"
          >
            <source src="https://assets.mixkit.co/videos/preview/mixkit-digital-animation-of-a-world-map-background-24581-large.mp4" type="video/mp4" />
          </video>
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <span className="inline-block px-4 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-500 text-xs font-bold uppercase tracking-[0.2em]">
              Strategic Innovation Platform
            </span>
            <h1 className="text-6xl md:text-8xl font-black tracking-tighter leading-[0.9] max-w-4xl mx-auto">
              WHERE GLOBAL <span className="text-orange-500">IDEAS</span> BECOME REALITY.
            </h1>
            <p className="text-lg md:text-xl text-white/60 max-w-2xl mx-auto font-medium">
              Join the world's most exclusive hub for innovators, investors, and strategic thinkers.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 pt-8">
              <Link
                to="/ideas"
                className="group bg-orange-500 hover:bg-orange-600 text-white px-10 py-5 rounded-full font-bold text-lg flex items-center gap-3 transition-all transform hover:scale-105"
              >
                EXPLORE IDEAS
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <button className="flex items-center gap-4 text-white hover:text-orange-500 transition-colors font-bold group">
                <div className="w-14 h-14 rounded-full border border-white/20 flex items-center justify-center group-hover:border-orange-500 transition-colors">
                  <Play className="w-5 h-5 fill-current" />
                </div>
                WATCH VISION
              </button>
            </div>
          </motion.div>
        </div>

        {/* Floating Elements */}
        <motion.div
          animate={{ y: [0, -20, 0] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-20 left-10 hidden lg:block"
        >
          <div className="bg-white/5 backdrop-blur-xl p-6 rounded-3xl border border-white/10 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
              <span className="text-[10px] font-bold uppercase tracking-widest text-white/40">Live Network Status</span>
            </div>
            <div className="flex -space-x-3">
              {[1, 2, 3, 4].map((i) => (
                <img
                  key={i}
                  src={`https://i.pravatar.cc/100?u=${i}`}
                  alt="User"
                  className="w-10 h-10 rounded-full border-2 border-black"
                  referrerPolicy="no-referrer"
                />
              ))}
            </div>
            <p className="text-xs font-bold">450+ Active Now</p>
          </div>
        </motion.div>
      </section>

      {/* Stats Section */}
      <section className="py-24 px-6 relative overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="p-8 rounded-3xl bg-white/5 border border-white/10 hover:border-orange-500/50 transition-colors group"
              >
                <stat.icon className="w-8 h-8 text-orange-500 mb-6 group-hover:scale-110 transition-transform" />
                <h3 className="text-4xl font-black tracking-tighter mb-2">{stat.value}</h3>
                <p className="text-xs font-bold uppercase tracking-widest text-white/40">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Intelligence Modules */}
      <section className="py-32 px-6 bg-white/5">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col lg:flex-row items-end justify-between gap-12 mb-20">
            <div className="max-w-2xl space-y-6">
              <span className="text-orange-500 font-bold uppercase tracking-[0.2em] text-xs">Intelligence Modules</span>
              <h2 className="text-5xl md:text-7xl font-black tracking-tighter leading-[0.9]">
                STRATEGIC TOOLS FOR <span className="text-orange-500">GLOBAL</span> IMPACT.
              </h2>
            </div>
            <p className="text-white/60 max-w-md text-lg leading-relaxed">
              Our platform provides the necessary infrastructure to scale ideas from local concepts to global phenomena.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {modules.map((module, index) => (
              <motion.div
                key={module.title}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.2 }}
                viewport={{ once: true }}
                className="p-10 rounded-[2.5rem] bg-black border border-white/10 hover:border-orange-500 transition-all group relative overflow-hidden"
              >
                <div className={`w-16 h-16 ${module.color} rounded-2xl flex items-center justify-center mb-8 group-hover:rotate-12 transition-transform`}>
                  <module.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold mb-4">{module.title}</h3>
                <p className="text-white/60 leading-relaxed mb-8">{module.description}</p>
                <button className="flex items-center gap-2 text-orange-500 font-bold group/btn">
                  LEARN MORE
                  <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                </button>
                <div className="absolute -bottom-12 -right-12 w-32 h-32 bg-orange-500/10 blur-3xl rounded-full group-hover:bg-orange-500/20 transition-colors" />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 px-6 relative overflow-hidden">
        <div className="max-w-5xl mx-auto text-center space-y-12 relative z-10">
          <h2 className="text-5xl md:text-8xl font-black tracking-tighter leading-[0.8]">
            READY TO SHAPE THE <span className="text-orange-500 italic">FUTURE?</span>
          </h2>
          <p className="text-xl text-white/60 max-w-2xl mx-auto">
            Join a global network of visionaries and start your journey today.
          </p>
          <div className="flex flex-wrap justify-center gap-6">
            <Link to="/ideas" className="bg-white text-black px-12 py-5 rounded-full font-bold text-lg hover:bg-orange-500 hover:text-white transition-all transform hover:scale-105">
              BROWSE IDEAS
            </Link>
            <Link to="/investors" className="bg-transparent border-2 border-white/20 text-white px-12 py-5 rounded-full font-bold text-lg hover:border-orange-500 hover:text-orange-500 transition-all transform hover:scale-105">
              INVESTOR PORTAL
            </Link>
          </div>
        </div>

        {/* Decorative Background */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-orange-500/10 blur-[120px] rounded-full -z-10" />
      </section>
    </div>
  );
};

export default Home;
