import React from "react";
import { Link } from "react-router-dom";
import { Globe, Mail, Twitter, Linkedin, Instagram, ArrowRight } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-black text-white pt-24 pb-12 px-6 border-t border-white/10">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
          <div className="space-y-6">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center group-hover:rotate-12 transition-transform">
                <Globe className="text-white w-6 h-6" />
              </div>
              <span className="text-white font-bold text-xl tracking-tighter">GLOBAL IDEAS HUB</span>
            </Link>
            <p className="text-white/60 text-sm leading-relaxed max-w-xs">
              The world's premier strategic platform for global innovators, investors, and thinkers to share, invest in, and shop for groundbreaking ideas.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-orange-500 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-orange-500 transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-orange-500 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-bold uppercase tracking-widest mb-6 text-orange-500">Platform</h4>
            <ul className="space-y-4 text-sm text-white/60">
              <li><Link to="/ideas" className="hover:text-white transition-colors">Browse Ideas</Link></li>
              <li><Link to="/investors" className="hover:text-white transition-colors">Investor Portal</Link></li>
              <li><Link to="/shop" className="hover:text-white transition-colors">Digital Shop</Link></li>
              <li><a href="#" className="hover:text-white transition-colors">Strategic Roadmap</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Intelligence Modules</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-bold uppercase tracking-widest mb-6 text-orange-500">Company</h4>
            <ul className="space-y-4 text-sm text-white/60">
              <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Our Vision</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Press Kit</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-bold uppercase tracking-widest mb-6 text-orange-500">Newsletter</h4>
            <p className="text-sm text-white/60 mb-6">Stay updated with the latest strategic insights and global trends.</p>
            <form className="relative">
              <input
                type="email"
                placeholder="Email address"
                className="w-full bg-white/5 border border-white/10 rounded-full px-6 py-3 text-sm focus:outline-none focus:border-orange-500 transition-colors"
              />
              <button className="absolute right-2 top-2 w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center hover:bg-orange-600 transition-colors">
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>

        <div className="pt-12 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-6 text-[10px] uppercase tracking-[0.2em] text-white/40 font-bold">
          <p>© 2026 GLOBAL IDEAS HUB. ALL RIGHTS RESERVED.</p>
          <div className="flex items-center gap-8">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
